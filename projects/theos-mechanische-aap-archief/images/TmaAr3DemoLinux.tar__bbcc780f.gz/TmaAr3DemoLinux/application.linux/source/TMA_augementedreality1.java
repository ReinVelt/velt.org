import processing.core.*; 
import processing.xml.*; 

import codeanticode.gsvideo.*; 
import java.awt.Rectangle; 
import jp.nyatla.nyar4psg.*; 
import processing.opengl.*; 
import javax.media.opengl.*; 

import jp.nyatla.nyartoolkit.core.*; 
import jp.nyatla.nyartoolkit.core.labeling.artoolkit.*; 
import jp.nyatla.nyartoolkit.utils.*; 
import jp.nyatla.nyartoolkit.core.raster.*; 
import jp.nyatla.nyartoolkit.core.types.stack.*; 
import jp.nyatla.nyartoolkit.core.utils.*; 
import jp.nyatla.nyartoolkit.core.pickup.*; 
import jp.nyatla.nyartoolkit.core.rasterfilter.rgb2bin.*; 
import jp.nyatla.nyartoolkit.core.labeling.rlelabeling.*; 
import jp.nyatla.nyartoolkit.core.analyzer.raster.*; 
import jp.nyatla.nyartoolkit.core.rasterfilter.rgb2gs.*; 
import jp.nyatla.nyartoolkit.core.match.*; 
import jp.nyatla.nyartoolkit.core.param.*; 
import jp.nyatla.nyartoolkit.sample.*; 
import jp.nyatla.nyartoolkit.core.types.matrix.*; 
import jp.nyatla.nyartoolkit.core.transmat.optimize.*; 
import jp.nyatla.nyartoolkit.core.transmat.rotmatrix.*; 
import jp.nyatla.nyartoolkit.nyidmarker.data.*; 
import jp.nyatla.nyartoolkit.core.rasterfilter.gs2bin.*; 
import jp.nyatla.nyartoolkit.core.squaredetect.*; 
import jp.nyatla.nyartoolkit.detector.*; 
import jp.nyatla.nyartoolkit.core.rasterreader.*; 
import jp.nyatla.nyartoolkit.core.transmat.solver.*; 
import jp.nyatla.nyartoolkit.core.pca2d.*; 
import jp.nyatla.nyartoolkit.core.raster.rgb.*; 
import jp.nyatla.nyartoolkit.core.analyzer.raster.threshold.*; 
import jp.nyatla.nyartoolkit.nyidmarker.*; 
import jp.nyatla.nyartoolkit.core.labeling.*; 
import jp.nyatla.nyartoolkit.utils.j2se.*; 
import jp.nyatla.nyartoolkit.core.transmat.optimize.artoolkit.*; 
import jp.nyatla.nyar4psg.*; 
import jp.nyatla.nyartoolkit.core.analyzer.histogram.*; 
import jp.nyatla.nyartoolkit.core.rasterfilter.*; 
import jp.nyatla.nyartoolkit.core.transmat.*; 
import jp.nyatla.nyartoolkit.*; 
import jp.nyatla.nyartoolkit.core.types.*; 
import jp.nyatla.nyartoolkit.processor.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class TMA_augementedreality1 extends PApplet {





/**	NyARToolkit for proce55ing/0.3.0
	(c)2008-2010 nyatla
	airmail(at)ebony.plala.or.jp

        Modified for TMA requirements by Rein Velt (rein@mechanicape.com)
*/
 





GSCapture cam;
NyARBoard nya;
NyARBoard tma;
PFont font;
PImage logo;
PImage help;
int fail;




public void setup() {
  fail=0;
  //size(640,480,OPENGL);
   size(640,480,OPENGL);
  colorMode(RGB, 100);
  font=createFont("FFScala", 32);
  cam=new GSCapture(this,width,height);
  nya=new NyARBoard(this,width,height,"camera_para.dat","patt.hiro",80);
  logo=loadImage("tmalogo.png");
  help=loadImage("help.png");
  print(nya.VERSION);
  nya.gsThreshold=110;//(0<n<255) default=110
  nya.cfThreshold=0.4f;//(0.0<n<1.0) default=0.4
  nya.lostDelay=10;//(0<n) default=10
  
}




public void drawMarkerPos(int[][] points)
{
  textFont(font,10.0f);
  stroke(100,0,0);
  fill(100,0,0);
  for(int i=0;i<4;i++){
    ellipse(nya.pos2d[i][0], nya.pos2d[i][1],5,5);
  }
  fill(0,0,0);
  for(int i=0;i<4;i++){
    text("("+nya.pos2d[i][0]+","+nya.pos2d[i][1]+")",nya.pos2d[i][0],nya.pos2d[i][1]);
  }
}




public String angle2text(float a)
{
  int i=(int)degrees(a);
  i=(i>0?i:i+360);
  return (i<100?"  ":i<10?" ":"")+Integer.toString(i);
}


public String trans2text(float i)
{
  return (i<100?"  ":i<10?" ":"")+Integer.toString((int)i);
}



public void drawAR() {
  //background(255);

  if (cam.available() !=true) {
    return;
  }
  cam.read();

  hint(DISABLE_DEPTH_TEST);
  image(cam,0,0);

  hint(ENABLE_DEPTH_TEST);
  image(logo,0,0);
  fill(255,255,255);
  stroke(255,255,255);
  text("TMA augmented reality framework v0.11",10,470);
  fill(255,0,0);
    text("http://mechanicape.com",500,470);
  if(nya.detect(cam)){
    if ((nya.confidence*100)>50)
    {
      fail=0;
    }
    hint(DISABLE_DEPTH_TEST);
    //\u4e00\u81f4\u5ea6\u3092\u66f8\u304f
    textFont(font,25.0f);
    fill((int)((1.0f-nya.confidence)*100),(int)(nya.confidence*100),0);
    text((int)(nya.confidence*100)+"%",width-60,height-20);
    //\u30de\u30fc\u30ab\u306e\u89d2\u5ea6\u3001\u6c34\u5e73\u4f4d\u7f6e\u7b49
    pushMatrix();
    textFont(font,10.0f);
    fill(0,100,0,80);
    translate((nya.pos2d[0][0]+nya.pos2d[1][0]+nya.pos2d[2][0]+nya.pos2d[3][0])/4+50,(nya.pos2d[0][1]+nya.pos2d[1][1]+nya.pos2d[2][1]+nya.pos2d[3][1])/4+50);
    text("TRANS "+trans2text(nya.trans.x)+","+trans2text(nya.trans.y)+","+trans2text(nya.trans.z),0,0);
    text("ANGLE "+angle2text(nya.angle.x)+","+angle2text(nya.angle.y)+","+angle2text(nya.angle.z),0,15);
    popMatrix();    
    //\u30de\u30fc\u30ab\u306e\u4f4d\u7f6e\u3092\u63cf\u753b
    drawMarkerPos(nya.pos2d);
    hint(ENABLE_DEPTH_TEST);
    
    PGraphicsOpenGL pgl = (PGraphicsOpenGL) g;
    nya.beginTransform(pgl);//\u30de\u30fc\u30ab\u5ea7\u6a19\u7cfb\u3067\u306e\u63cf\u753b\u3092\u958b\u59cb\u3059\u308b\u3002
    //\u3053\u3053\u304b\u3089\u30de\u30fc\u30ab\u5ea7\u6a19\u7cfb
    stroke(0);
    //translate(0,0,20);
    translate(0,0,2);
    fill(0,0,255);
    
    //box(40);
    image(cam,-40,-40,80,80);
    //sphere(40);
    nya.endTransform();//\u30de\u30fc\u30ab\u5ea7\u6a19\u7cfb\u3067\u306e\u63cf\u753b\u3092\u7d42\u4e86\u3059\u308b\u3002\uff08\u5fc5\u305a\u547c\u3093\u3067\uff01\uff09
  }
  else
  {
   fail++; 
  }
}



public void help()
{
  
}


  public void draw()
  {
   
   drawAR();
   if (fail>50)
   {
      image(help,0,0);
   }


  }
  
  



  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#DFDFDF", "TMA_augementedreality1" });
  }
}
